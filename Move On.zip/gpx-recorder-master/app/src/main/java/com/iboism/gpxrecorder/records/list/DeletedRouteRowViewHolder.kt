package com.iboism.gpxrecorder.records.list

import androidx.recyclerview.widget.RecyclerView
import com.iboism.gpxrecorder.databinding.ListRowDeletedRouteBinding

class DeletedRouteRowViewHolder(binding: ListRowDeletedRouteBinding): RecyclerView.ViewHolder(binding.root) {
    val rootView = binding.root
}