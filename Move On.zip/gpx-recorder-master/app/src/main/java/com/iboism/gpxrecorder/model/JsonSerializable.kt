package com.iboism.gpxrecorder.model

interface JsonSerializable {
    fun getJsonString(): String
}