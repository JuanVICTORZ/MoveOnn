package com.iboism.gpxrecorder.util

class Holder<T>(val value: T)