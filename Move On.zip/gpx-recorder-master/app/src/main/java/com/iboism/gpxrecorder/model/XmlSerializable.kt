package com.iboism.gpxrecorder.model

/**
 * Created by Brad on 11/18/2017.
 */

interface XmlSerializable {
    fun getXmlString(): String
}